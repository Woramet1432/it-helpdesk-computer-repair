import { Router } from 'express';
import authRoutes from './authRoutes.ts';
import ticketRoutes from './ticketRoutes.ts';
import assetRoutes from './assetRoutes.ts';
import userRoutes from './userRoutes.ts';
import reportRoutes from './reportRoutes.ts';
import auditRoutes from './auditRoutes.ts';
import uploadRoutes from './uploadRoutes.ts';

const apiRouter = Router();

apiRouter.use('/auth', authRoutes);
apiRouter.use('/tickets', ticketRoutes);
apiRouter.use('/assets', assetRoutes);
apiRouter.use('/users', userRoutes);
apiRouter.use('/reports', reportRoutes);
apiRouter.use('/audit-logs', auditRoutes);
apiRouter.use('/uploads', uploadRoutes);

apiRouter.get('/health', (_req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: 'IT Helpdesk & Computer Repair API',
  });
});

export default apiRouter;
